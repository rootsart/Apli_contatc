<?php
namespace App\Router;

class Router

{
	protected $url;
	protected $action;
	protected $module;
	protected $page;

	public function __construct()
	{
		$this->setPage();
		$this->setUrl($this->page());
		$this->setModule($this->page());	
	}

	
	public function getAction(){
		// Dans le cas action comporte un / ou un chiffre, sbstr permet de garder le nécéssaire.
		$url = $this->Url();
		$url = $url[1];
		$pos = strpos($url, '/');
		if($pos >0){
		$action =  substr($url, 0, $pos);	
		}else{
			$action = $url;
		}
		return $action;
	}

	// -------------- Setters ---------------
	public function setPage()
	{
		if (isset($_GET['p'])) {
			$this->page = $_GET['p'];

		} else {
			$this->page = 'contact.index';
		}
		$this->page = explode('.', $this->page);
	}
	public function setUrl($page)
	{
		$this->url = $page;
	}

	public function setModule($page)
	{
		$this->module = $page[0];
	}
	// -------------- Getters ---------------
	public function page()
	{
		return $this->page;
	}
	public function Url()
	{
		return $this->url;
	}
	
	public function module()
	{
		return $this->module;
	}
	
}