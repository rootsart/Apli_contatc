<?php

define('ROOT', dirname(__DIR__ . '/..'));
require ROOT . '/app/App.php';
App::load();

$router = '\App\Router\Router';
$router = new $router();
$action = $router->getAction();
$controller = '\App\Controllers\\' . ucfirst($router->module()) . 'Controller';
$controller = new $controller();
$controller->$action();
