<?php
namespace App\Router;

class Router

{
	protected $url;
	protected $action;
	protected $module;

	public function __construct($url)
	{
		$this->setUrl($url);
		$this->setModule($url);
	}

	
	public function getAction(){
		// Dans le cas action comporte un / ou un chiffre, sbstr permet de garder le nécéssaire.
		$url = $this->Url();
		$url = $url[1];
		$pos = strpos($url, '/');
		if($pos >0){
		$action =  substr($url, 0, $pos);	
		}else{
			$action = $url;
		}
		return $action;
	}

	// -------------- Setters ---------------
	public function setUrl($url)
	{
		$this->url = $url;
	}

	public function setModule($url)
	{
		$this->module = $url[0];
	}
	// -------------- Getters ---------------
	public function Url()
	{
		return $this->url;
	}
	
	public function Module()
	{
		return $this->module;
	}
	
}