<?php

define('ROOT', dirname(__DIR__ . '/..'));
require ROOT . '/app/App.php';
App::load();
if (isset($_GET['p'])) {
    $page = $_GET['p'];
   // echo stristr($email, 'e', true);

} else {
    $page = 'contact.index';
}


$page = explode('.', $page);
$controller = '\App\Controllers\\' . ucfirst($page[0]) . 'Controller';

$controller = new $controller();
$router = '\App\Router\Router';
$router = new $router($page);
$action = $router->getAction();
$controller->$action();
