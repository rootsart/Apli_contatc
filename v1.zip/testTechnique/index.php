<?php

define('ROOT', dirname(__DIR__ . '/..'));
require ROOT . '/app/App.php';
App::load();
if (isset($_GET['p'])) {
    $page = $_GET['p'];
   // echo stristr($email, 'e', true);

} else {
    $page = 'contact.index';
}


$page = explode('.', $page);
$controller = '\App\Controllers\\' . ucfirst($page[0]) . 'Controller';
$action = $page[1];

// ---- On enlève le n° et le / si ils existent, dans le cas par exemple d'ajouts d'adresses
$pos = strpos($action, '/');
if($pos >0){
	$action =  substr($action, 0, $pos);	
}
echo "<br>" . $page[0] . $page[1] . "<br>";
$controller = new $controller();
$controller->$action();
