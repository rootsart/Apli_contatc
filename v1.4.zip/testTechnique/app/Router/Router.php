<?php
namespace App\Router;

class Router

{
	protected $page;
	protected $action;

	public function __construct($page)
	{
		$this->setPage($page);
	}

	
	public function getAction(){
		$page = $this->page();
		$page = $page[1];
		$pos = strpos($page, '/');
		if($pos >0){
		$action =  substr($page, 0, $pos);	
		}else{
			$action = $page;
		}
		
		return $action;
	}

	// -------------- Setters ---------------
	public function setPage($page)
	{
		$this->page = $page;
	}

	// -------------- Getters ---------------
	public function page()
	{
		return $this->page;
	}
	
}